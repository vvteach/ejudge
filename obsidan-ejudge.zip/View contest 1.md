```dataviewjs

const folder = "tasks";
const contest = "004805";

// получаем задачи
const files = dv.pages(`"${folder}"`)
    .filter(p => p.tags?.some(t => t.includes(`problem/contest/${contest}/`)))
    .sort(
        p => p.tags.find(t => t.includes(`problem/contest/${contest}/`)),
        'asc'
    );

for (const p of files) {

    // 1 — буква задачи
    const taskTag = p.tags.find(t => t.includes(`problem/contest/${contest}/`));
    const letter = taskTag.split("/").pop();

// 2 — origin (любой)
let originText = "";
// получаем все теги как массив строк
const tagsList = Array.isArray(p.tags) ? p.tags : Array.isArray(p.tags?.values) ? p.tags.values : [];
const originTag = tagsList.find(t => t.startsWith("#problems/origin/") || t.startsWith("problems/origin/"));
if (originTag) {
    const parts = originTag.replace(/^#/, "").split("/"); // убираем #
    if (parts.length >= 4) {
        const source = parts[2];   // informatics, codeforces и т.д.
        const num = parts[3];      // номер задачи
        originText = `[[tasks/${source}/${num}|${source}/${num}]]`;
    }
}

    // 3 — заголовок
   let title = p.title ?? p.file.name;
// Убираем "Задача №<число>. " из начала
title = title.replace(/^Задача №\d+\.\s*/, "");
const fullTitle = `# Задача ${letter} (${originText}) ${title}`;

    dv.el("div", fullTitle, { markdown: true });

    // 4 — читаем файл
    const file = app.vault.getAbstractFileByPath(p.file.path);
    let content = await app.vault.read(file);

    // 5 — убираем YAML-блок, если есть
    if (content.startsWith("---")) {
        const parts = content.split("---");
        if (parts.length > 2) {
            content = parts.slice(2).join("---").trim(); // оставляем текст после YAML
        } else {
            content = parts.slice(1).join("---").trim();
        }
    }

    // 6 — удаляем первую строку текста (обычно старый заголовок)
    const lines = content.split("\n");
    lines.shift();
    content = lines.join("\n").trim();

    // 7 — выводим тело задачи
    dv.el("div", content, { markdown: true });

    // 8 — разделитель
    dv.el("hr", "");
}
