[Contest 203126](obsidian://open?file=View%20contest&prepend=abc&contest_id=456)

