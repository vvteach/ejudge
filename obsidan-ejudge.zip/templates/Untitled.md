// File include 
<%* await tp.file.include("[[View contest]]") %>